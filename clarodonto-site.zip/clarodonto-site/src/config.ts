// Dados centralizados. WhatsApp somente dígitos, com DDI e DDD.
export const clinic = {
  address: 'Rua Barão de São João Nepomuceno, 312 – Centro',
  city: 'Juiz de Fora · MG',
  phone: '(32) 98831-0407',
  phoneHref: '+5532988310407',
  whatsapp: '5532988310407',
  hours: ['Segunda a sexta: 09h às 19h', 'Sábado: 09h30 às 14h', 'Domingo: fechado'],
  instagram: '',
  mapUrl: 'https://maps.app.goo.gl/eyKQk6oEgXLiqjFy7',
  mapQuery: 'Clarodonto, Rua Barão de São João Nepomuceno, 312, Centro, Juiz de Fora, MG, 36010-081',
  googleReviews: 'https://www.google.com/maps/place/Clarodonto/@-21.7618878,-43.3508018,17z/data=!4m8!3m7!1s0x989b5d2bb3f55f:0x2da8affeaf9588c!8m2!3d-21.7618928!4d-43.3482269!9m1!1b1!16s%2Fg%2F1ptxb5jwr?hl=pt-BR',
  whatsappMessage: 'Olá! Gostaria de saber mais sobre o atendimento na Clarodonto.',
};
export const whatsappUrl = clinic.whatsapp ? `https://wa.me/${clinic.whatsapp}?text=${encodeURIComponent(clinic.whatsappMessage)}` : '';

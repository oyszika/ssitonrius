import React, {useEffect} from 'react';
import {createRoot} from 'react-dom/client';
import Header from './components/Header';
import Hero from './components/Hero';
import Intro from './components/Intro';
import Treatments from './components/Treatments';
import Spaces from './components/Spaces';
import {Details,Team,Reviews} from './components/Details';
import Contact,{Footer} from './components/Contact';
import {FloatingContact} from './components/Shared';
import './style.css';
function App(){useEffect(()=>{const els=document.querySelectorAll('.reveal');if(!('IntersectionObserver' in window)){els.forEach(el=>el.classList.add('visible'));return}const observer=new IntersectionObserver(entries=>entries.forEach(entry=>{if(entry.isIntersecting){entry.target.classList.add('visible');observer.unobserve(entry.target)}}),{threshold:.08});els.forEach(el=>observer.observe(el));return()=>observer.disconnect()},[]);return <><Header/><main><Hero/><Intro/><Treatments/><Spaces/><Details/><Team/><Reviews/><Contact/></main><Footer/><FloatingContact/></>}

createRoot(document.getElementById('root')!).render(<React.StrictMode><App/></React.StrictMode>);

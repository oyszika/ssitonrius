import {useEffect, useState} from 'react';
import {Menu, X, ArrowUpRight} from 'lucide-react';
import {Logo} from './Shared';
import {whatsappUrl} from '../config';
const nav = [['Início','#inicio'],['A clínica','#clinica'],['Tratamentos','#tratamentos'],['Estrutura','#estrutura'],['Contato','#contato']];
export default function Header(){
 const [scrolled,setScrolled] = useState(false); const [open,setOpen] = useState(false);
 useEffect(()=>{const onScroll=()=>setScrolled(window.scrollY>40); onScroll(); window.addEventListener('scroll',onScroll,{passive:true}); return ()=>window.removeEventListener('scroll',onScroll)},[]);
 useEffect(()=>{document.body.classList.toggle('menu-open',open); return ()=>document.body.classList.remove('menu-open')},[open]);
 return <header className={`header ${scrolled ? 'header-solid' : ''} ${open ? 'header-open' : ''}`}><div className="header-inner"><Logo light/><nav className="desktop-nav" aria-label="Navegação principal">{nav.map(([label,href])=><a key={href} href={href}>{label}</a>)}</nav><a href={whatsappUrl || '#contato'} target={whatsappUrl ? '_blank' : undefined} rel={whatsappUrl ? 'noopener noreferrer' : undefined} className="header-cta">Agendar consulta <ArrowUpRight size={15}/></a><button className="menu-toggle" onClick={()=>setOpen(!open)} aria-expanded={open} aria-label={open?'Fechar menu':'Abrir menu'}>{open?<X/>:<Menu/>}</button></div><nav className={`mobile-nav ${open?'is-open':''}`} aria-label="Navegação móvel">{nav.map(([label,href],i)=><a onClick={()=>setOpen(false)} key={href} href={href}><small>0{i+1}</small>{label}<ArrowUpRight size={19}/></a>)}<a className="mobile-appointment" href={whatsappUrl || '#contato'} onClick={()=>setOpen(false)}>Agendar consulta <ArrowUpRight size={17}/></a></nav></header>
}

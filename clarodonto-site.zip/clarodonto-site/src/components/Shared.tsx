import { ArrowDownRight, ArrowUpRight, MessageCircle } from 'lucide-react';
import { whatsappUrl } from '../config';

export function Logo({light = false}: {light?: boolean}) {
 return <a className={`brand ${light ? 'brand-light' : ''}`} href="#inicio" aria-label="Clarodonto, voltar ao início"><img className="brand-logo" src="/images/logo-clarodonto.png" alt=""/><span><strong>CLARODONTO</strong><small>APERFEIÇOANDO SORRISOS</small></span></a>
}
export function Label({children, light = false}: {children: React.ReactNode, light?: boolean}) { return <div className={`eyebrow ${light ? 'eyebrow-light' : ''}`}><span className="label-line"/>{children}</div> }
export function ContactButton({children = 'Agendar uma consulta', outline = false, className = ''}: {children?: React.ReactNode, outline?: boolean, className?: string}) {
 return <a href={whatsappUrl || '#contato'} target={whatsappUrl ? '_blank' : undefined} rel={whatsappUrl ? 'noopener noreferrer' : undefined} className={`button ${outline ? 'button-outline' : 'button-gold'} ${className}`}>{children}<ArrowUpRight size={16}/></a>
}
export function TextLink({children, href, light = false}: {children: React.ReactNode, href: string, light?: boolean}) {return <a className={`text-link ${light ? 'text-link-light' : ''}`} href={href}>{children}<ArrowDownRight size={16}/></a>}
export function FloatingContact(){return <a href={whatsappUrl || '#contato'} target={whatsappUrl ? '_blank' : undefined} rel={whatsappUrl ? 'noopener noreferrer' : undefined} className="floating-contact" aria-label={whatsappUrl ? 'Conversar pelo WhatsApp' : 'Ir para informações de contato'}><MessageCircle size={21}/></a>}

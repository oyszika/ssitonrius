# Clarodonto — proposta demonstrativa

Site institucional em React, TypeScript e Vite. As fotos da recepção, do consultório e do equipamento foram fornecidas para esta proposta. A fotografia ampla adicional mencionada no briefing não foi anexada; a recepção disponível foi reutilizada.

## Executar

```bash
npm install
npm run dev
```

Para gerar a versão de produção: `npm run build`.

## Antes de publicar

- Os dados de telefone, WhatsApp e endereço informados estão em `src/config.ts`. O WhatsApp deve conter somente dígitos, incluindo DDI e DDD. Os horários informados pelo cliente estão na seção de contato; redes sociais continuam aguardando confirmação.
- Confirme os serviços oferecidos e substitua os conteúdos demonstrativos, incluindo equipe. Os trechos de avaliações são públicos e estáticos; confirme autorização e conformidade antes de publicar nomes e especialmente fotografias dos avaliadores. As ilustrações dos tratamentos são esquemáticas.
- O formulário valida os campos e abre uma mensagem preenchida no WhatsApp, para revisão e envio manual. Revise o tratamento de dados e a política de privacidade antes de publicar.
- Revise a identificação profissional, conteúdos e demais requisitos aplicáveis da publicidade odontológica com a clínica e seus responsáveis.
- Ajuste a URL absoluta da imagem Open Graph e domínio definitivo na publicação.
